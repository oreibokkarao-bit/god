
import asyncio
from time import monotonic

class TokenBucket:
    def __init__(self, rate_per_sec: float, burst: int):
        self.rate = rate_per_sec
        self.burst = burst
        self.tokens = burst
        self.updated = monotonic()
        self._lock = asyncio.Lock()

    async def take(self, tokens=1):
        async with self._lock:
            now = monotonic()
            self.tokens = min(self.burst, self.tokens + (now - self.updated) * self.rate)
            self.updated = now
            while self.tokens < tokens:
                await asyncio.sleep((tokens - self.tokens) / self.rate)
                now = monotonic()
                self.tokens = min(self.burst, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
            self.tokens -= tokens
