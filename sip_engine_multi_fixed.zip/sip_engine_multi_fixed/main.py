
import asyncio, logging, yaml
from datetime import datetime, timezone
from typing import Dict, Any

from data.multi_exchange_data_handler import MultiExchangeSpotData
from features.features_engine import FeatureEngine
from signals.signal_generator import SignalGenerator
from risk.risk_runner import RiskManagerRunner
from ui.console_ui import ConsoleUI

def setup_logging(level: str = "INFO"):
    lvl = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(level=lvl, format="%(asctime)s - %(levelname)s - [%(name)s] - %(message)s",
                        datefmt="%%Y-%%m-%%d %%H:%%M:%%S")
    logging.getLogger("websockets").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)

def load_config(path: str) -> Dict[str, Any]:
    with open(path, "r") as f:
        return yaml.safe_load(f)

async def main():
    setup_logging()
    cfg = load_config("config.yaml")
    logging.info("Starting Unified Spot Engine…")

    q_trades = asyncio.Queue(maxsize=50000)
    q_books  = asyncio.Queue(maxsize=5000)
    q_feats  = asyncio.Queue(maxsize=5000)
    q_signals= asyncio.Queue(maxsize=1000)
    q_orders = asyncio.Queue(maxsize=1000)

    data = MultiExchangeSpotData(cfg, q_trades, q_books)
    feats = FeatureEngine(cfg, {"trades": q_trades, "order_books": q_books}, q_feats)
    sigs  = SignalGenerator(cfg, q_feats, q_signals)
    risk  = RiskManagerRunner(cfg, q_signals, q_orders)
    ui    = ConsoleUI(cfg, q_orders)

    tasks = [asyncio.create_task(c) for c in (data.run(), feats.run(), sigs.run(), risk.run(), ui.run())]
    try:
        await asyncio.gather(*tasks)
    except asyncio.CancelledError:
        pass
    finally:
        for t in tasks: t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

if __name__ == "__main__":
    logging.getLogger().info(f"Launch @ {datetime.now(timezone.utc).isoformat()}")
    asyncio.run(main())
