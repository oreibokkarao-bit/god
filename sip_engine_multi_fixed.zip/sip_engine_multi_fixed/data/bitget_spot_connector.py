
import asyncio, aiohttp, websockets, json, logging
from typing import List, Dict, Any
from data.exchange_base import ExchangeConnector
from common.symbols import unify_symbol
from common.rate_limiter import TokenBucket

REST = "https://api.bitget.com"
WS   = "wss://ws.bitget.com/spot/v1/stream"

class BitgetSpotConnector(ExchangeConnector):
    name = "bitget"
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.log = logging.getLogger(self.__class__.__name__)
        self.bucket = TokenBucket(rate_per_sec=8.0, burst=8)

    async def fetch_symbols(self) -> List[str]:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{REST}/api/v2/spot/public/symbols", timeout=20) as r:
                r.raise_for_status()
                data = await r.json()
        syms = [d["symbol"] for d in data.get("data", []) if str(d.get("status","online")).lower() in ("online","trading","1")]
        quotes = set(x.upper() for x in self.cfg.get("quote_whitelist", []))
        if quotes:
            flt = []
            for sym in syms:
                up = unify_symbol(sym)
                quote = None
                for q in ("USDT","FDUSD","TUSD","USDC","BUSD","USD","TRY","EUR","BRL","ETH","BTC"):
                    if up.endswith(q): quote = q; break
                if quote in quotes:
                    flt.append(up)
            syms = flt
        return sorted(set(unify_symbol(s) for s in syms))

    async def _ws_shard(self, symbols: List[str], out_queue: asyncio.Queue):
        url = WS
        args_trade = [{"instType":"SPOT","channel":"trade","instId":s} for s in symbols]
        args_depth = [{"instType":"SPOT","channel":"depth","instId":s} for s in symbols]
        self.log.info(f"Bitget shard connect: {len(symbols)} syms")
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                    batch = int(self.cfg.get("bitget_args_per_sub", 100))
                    for i in range(0, len(args_trade), batch):
                        await self.bucket.take(1)
                        await ws.send(json.dumps({"op":"subscribe","args": args_trade[i:i+batch]}))
                        await asyncio.sleep(0.2)
                    for i in range(0, len(args_depth), batch):
                        await self.bucket.take(1)
                        await ws.send(json.dumps({"op":"subscribe","args": args_depth[i:i+batch]}))
                        await asyncio.sleep(0.2)
                    async for raw in ws:
                        msg = json.loads(raw)
                        if "arg" not in msg or "data" not in msg: continue
                        ch = msg["arg"].get("channel","")
                        if ch == "trade":
                            for t in msg["data"]:
                                sym = unify_symbol(t.get("instId") or msg["arg"].get("instId"))
                                taker = "buy" if str(t.get("side","buy")).lower().startswith("buy") else "sell"
                                await out_queue.put({"type":"trade","symbol":sym,"ts":int(t.get("ts") or t.get("T")),
                                                     "price":float(t["px"]), "qty":float(t["sz"]), "taker":taker,
                                                     "exchange": self.name})
                        elif ch == "depth":
                            d = msg["data"][0] if isinstance(msg["data"], list) and msg["data"] else msg["data"]
                            sym = unify_symbol(d.get("instId") or msg["arg"].get("instId"))
                            bids = [[float(x[0]), float(x[1])] for x in d.get("bids",[])]
                            asks = [[float(x[0]), float(x[1])] for x in d.get("asks",[])]
                            await out_queue.put({"type":"depth","symbol":sym,"exchange":self.name,"bids":bids,"asks":asks})
            except Exception as e:
                self.log.error(f"Bitget shard error: {e}. Reconnecting in 5s…")
                await asyncio.sleep(5)

    async def stream(self, out_queue: asyncio.Queue):
        all_syms: List[str] = self.cfg.get("_bitget_symbols_cache") or await self.fetch_symbols()
        self.cfg["_bitget_symbols_cache"] = all_syms
        per_socket = int(self.cfg.get("bitget_symbols_per_socket", 200))
        tasks = []
        for i in range(0, len(all_syms), per_socket):
            chunk = all_syms[i:i+per_socket]
            tasks.append(asyncio.create_task(self._ws_shard(chunk, out_queue)))
        await asyncio.gather(*tasks)
