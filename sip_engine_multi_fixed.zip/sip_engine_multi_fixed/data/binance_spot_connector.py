
import asyncio, aiohttp, websockets, json, logging
from typing import List, Dict, Any
from data.exchange_base import ExchangeConnector
from common.symbols import unify_symbol

REST = "https://api.binance.com/api/v3"
WS   = "wss://stream.binance.com:9443"

class BinanceSpotConnector(ExchangeConnector):
    name = "binance"
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.log = logging.getLogger(self.__class__.__name__)

    async def fetch_symbols(self) -> List[str]:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{REST}/exchangeInfo", timeout=20) as r:
                r.raise_for_status()
                data = await r.json()
        syms = []
        for item in data.get("symbols", []):
            if item.get("status") == "TRADING" and item.get("isSpotTradingAllowed"):
                syms.append(item["symbol"])
        quotes = set(x.upper() for x in self.cfg.get("quote_whitelist", []))
        if quotes:
            flt = []
            for sym in syms:
                up = unify_symbol(sym)
                quote = None
                for q in ("USDT","FDUSD","TUSD","USDC","BUSD","USD","TRY","EUR","BRL","ETH","BTC"):
                    if up.endswith(q): quote = q; break
                if quote in quotes:
                    flt.append(up)
            syms = flt
        return sorted(set(unify_symbol(s) for s in syms))

    async def _ws_shard(self, symbols: List[str], out_queue: asyncio.Queue):
        streams = [f"{s.lower()}@aggTrade" for s in symbols]
        streams += [f"{s.lower()}@depth" for s in symbols]
        url = f"{WS}/stream?streams={'/'.join(streams)}"
        self.log.info(f"Binance shard connect: {len(symbols)} syms / {len(streams)} streams")
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                    async for raw in ws:
                        msg = json.loads(raw)
                        stream = msg.get("stream","")
                        data = msg.get("data",{})
                        sym = unify_symbol(stream.split("@")[0])
                        if "@aggTrade" in stream:
                            taker = "sell" if data.get("m") else "buy"
                            await out_queue.put({"type":"trade","symbol":sym,"ts":data.get("T"),
                                                 "price":float(data["p"]), "qty":float(data["q"]),
                                                 "taker":taker, "exchange":self.name})
                        elif "@depth" in stream:
                            bids = [[float(p), float(sz)] for p,sz in data.get("b",[])]
                            asks = [[float(p), float(sz)] for p,sz in data.get("a",[])]
                            await out_queue.put({"type":"depth","symbol":sym,"exchange":self.name,"bids":bids,"asks":asks})
            except Exception as e:
                self.log.error(f"Binance shard error: {e}. Reconnecting in 5s…")
                await asyncio.sleep(5)

    async def stream(self, out_queue: asyncio.Queue):
        all_syms: List[str] = self.cfg.get("_binance_symbols_cache") or await self.fetch_symbols()
        self.cfg["_binance_symbols_cache"] = all_syms
        per_socket = min(int(self.cfg.get("binance_symbols_per_socket", 400)), 512)
        tasks = []
        for i in range(0, len(all_syms), per_socket):
            chunk = all_syms[i:i+per_socket]
            tasks.append(asyncio.create_task(self._ws_shard(chunk, out_queue)))
        await asyncio.gather(*tasks)
