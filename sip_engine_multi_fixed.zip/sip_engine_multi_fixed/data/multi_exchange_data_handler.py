
import asyncio, logging
from typing import Dict, Any

from data.binance_spot_connector import BinanceSpotConnector
from data.bybit_spot_connector import BybitSpotConnector
from data.bitget_spot_connector import BitgetSpotConnector

class MultiExchangeSpotData:
    def __init__(self, config: Dict[str, Any], trades_queue: asyncio.Queue, book_queue: asyncio.Queue):
        self.log = logging.getLogger(self.__class__.__name__)
        self.cfg = config
        self.q_trades = trades_queue
        self.q_books  = book_queue
        self.include = set(x.lower() for x in self.cfg.get("exchanges", ["binance","bybit","bitget"]))
        self._last_books: Dict[str, Dict[str, Any]] = {}

    async def run(self):
        tasks = []
        if "binance" in self.include:
            tasks.append(asyncio.create_task(self._run_connector(BinanceSpotConnector)))
        if "bybit" in self.include:
            tasks.append(asyncio.create_task(self._run_connector(BybitSpotConnector)))
        if "bitget" in self.include:
            tasks.append(asyncio.create_task(self._run_connector(BitgetSpotConnector)))
        tasks.append(asyncio.create_task(self._book_coalescer()))
        await asyncio.gather(*tasks)

    async def _run_connector(self, cls):
        q = asyncio.Queue(maxsize=10000)
        conn = cls(self.cfg)
        async def pump():
            await conn.stream(q)
        async def consume():
            while True:
                e = await q.get()
                if e.get("type") == "trade":
                    await self.q_trades.put(e)
                elif e.get("type") == "depth":
                    sym = e["symbol"]; ex = e["exchange"]
                    book = self._last_books.setdefault(sym, {"by_exchange":{}})
                    book["by_exchange"][ex] = {"bids": e["bids"], "asks": e["asks"]}
        return await asyncio.gather(pump(), consume())

    async def _book_coalescer(self):
        import asyncio
        from collections import defaultdict
        while True:
            await asyncio.sleep(self.cfg.get("book_merge_sec", 1))
            for sym, info in list(self._last_books.items()):
                by_ex = info.get("by_exchange", {})
                if not by_ex: continue
                N = int(self.cfg.get("book_merge_levels", 10))
                price_to_bid = defaultdict(float)
                price_to_ask = defaultdict(float)
                for ex, b in by_ex.items():
                    for p,sz in (b.get("bids", [])[:N]):
                        price_to_bid[p] += sz
                    for p,sz in (b.get("asks", [])[:N]):
                        price_to_ask[p] += sz
                bids = sorted([[p, sz] for p,sz in price_to_bid.items()], key=lambda x: x[0], reverse=True)[:N]
                asks = sorted([[p, sz] for p,sz in price_to_ask.items()], key=lambda x: x[0])[:N]
                await self.q_books.put({"symbol": sym, "book": {"bids": bids, "asks": asks, "sync_complete": True}})
