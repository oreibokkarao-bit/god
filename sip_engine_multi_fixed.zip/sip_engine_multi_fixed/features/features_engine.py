
import asyncio, logging
from collections import defaultdict, deque
from typing import Dict, Any, Deque, List
from features.features_module import calculate_spot_cvd, calculate_ob_imbalance

class FeatureEngine:
    def __init__(self, config: Dict[str, Any], data_queues: Dict[str, asyncio.Queue], feature_queue: asyncio.Queue):
        self.log = logging.getLogger(self.__class__.__name__)
        self.cfg = config
        self.q_trades: asyncio.Queue = data_queues["trades"]
        self.q_books: asyncio.Queue  = data_queues["order_books"]
        self.q_out: asyncio.Queue    = feature_queue
        self.trades_buf: Dict[str, Deque[Dict[str, Any]]] = defaultdict(lambda: deque(maxlen=6000))
        self.last_book: Dict[str, Dict[str, Any]] = {}
        self.feature_interval_sec = int(self.cfg.get("feature_interval_sec", 5))

    async def run(self):
        self.log.info("FeatureEngine running (multi-exchange).")
        consumers = [asyncio.create_task(self._consume_trades()),
                     asyncio.create_task(self._consume_books()),
                     asyncio.create_task(self._emit_loop())]
        try:
            await asyncio.gather(*consumers)
        finally:
            for t in consumers: t.cancel()

    async def _consume_trades(self):
        while True:
            e = await self.q_trades.get()
            self.trades_buf[e["symbol"]].append(e)

    async def _consume_books(self):
        while True:
            e = await self.q_books.get()
            self.last_book[e["symbol"]] = e["book"]

    async def _emit_loop(self):
        while True:
            await asyncio.sleep(self.feature_interval_sec)
            for sym, buf in list(self.trades_buf.items()):
                try:
                    feats = self._compute(sym, list(buf), self.last_book.get(sym))
                    if feats:
                        await self.q_out.put({"symbol": sym, "features": feats})
                except Exception as ex:
                    self.log.error(f"Feature calc failed for {sym}: {ex}", exc_info=True)

    def _compute(self, sym: str, trades: List[Dict[str, Any]], book: Dict[str, Any] | None):
        if not trades: return None
        last_ts = trades[-1]["ts"]; cutoff = last_ts - 60_000
        recent = [t for t in trades if t["ts"] >= cutoff]
        cvd_slope = 0.0
        if recent:
            cvd_df = calculate_spot_cvd(recent)
            if not cvd_df.empty:
                cvd_slope = float(cvd_df["cvd"].iloc[-1] - cvd_df["cvd"].iloc[0])
        ob_imb = 0.5
        if book:
            ob_imb = float(calculate_ob_imbalance(book))
        return {"cvd_slope_1m": cvd_slope, "ob_imbalance": ob_imb}
