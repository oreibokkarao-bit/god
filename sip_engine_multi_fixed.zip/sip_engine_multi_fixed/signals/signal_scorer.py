
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer

class SignalScorer:
    def __init__(self, weights: dict):
        self.weights = weights
        self.normalizer = MinMaxScaler(feature_range=(0, 100))
        self.imputer = SimpleImputer(strategy='mean')

    def _normalize_features(self, features_df: pd.DataFrame) -> pd.DataFrame:
        if features_df.empty: return pd.DataFrame()
        imputed_data = self.imputer.fit_transform(features_df)
        features_imputed_df = pd.DataFrame(imputed_data, index=features_df.index, columns=features_df.columns)
        normalized_data = self.normalizer.fit_transform(features_imputed_df)
        return pd.DataFrame(normalized_data, index=features_df.index, columns=features_df.columns)

    def calculate_sip_score(self, features_df: pd.DataFrame) -> pd.DataFrame:
        if features_df.empty:
            return pd.DataFrame(columns=['stealth_score','ignition_score','propulsion_score','sip_score'])
        nf = self._normalize_features(features_df)
        stealth = self._sub(nf, 'stealth_features')
        ignition = self._sub(nf, 'ignition_features')
        propulsion = self._sub(nf, 'propulsion_features')
        out = pd.DataFrame({'stealth_score': stealth, 'ignition_score': ignition, 'propulsion_score': propulsion}, index=features_df.index)
        w = self.weights['sip_sub_scores']
        out['sip_score'] = out['stealth_score']*w.get('stealth',0) + out['ignition_score']*w.get('ignition',0) + out['propulsion_score']*w.get('propulsion',0)
        return out.round(2)

    def _sub(self, nf: pd.DataFrame, group: str):
        import pandas as pd
        sub = pd.Series(0.0, index=nf.index)
        weights = self.weights.get(group, {})
        total = sum(weights.values())
        if total == 0: return sub
        for f,w in weights.items():
            if f in nf.columns:
                sub += nf[f]*w
        return sub/total
