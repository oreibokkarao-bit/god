
class DrawdownThrottle:
    def __init__(self, high_water_mark: float, config: dict):
        self.high_water_mark = high_water_mark
        self.current_equity = high_water_mark
        self.config = config
        self.state = 'NORMAL'
    def update_equity(self, new_equity: float):
        self.current_equity = new_equity
        self.high_water_mark = max(self.high_water_mark, new_equity)
        self._update_state()
    def _update_state(self):
        hwm = max(self.high_water_mark, 1e-9)
        dd = (self.high_water_mark - self.current_equity)/hwm
        self.state = 'HALTED' if dd >= self.config.get('halt_level',0.25) else ('REDUCED_RISK' if dd >= self.config.get('warn_level',0.15) else 'NORMAL')
    def get_risk_factor(self) -> float:
        return 0.0 if self.state=='HALTED' else (0.5 if self.state=='REDUCED_RISK' else 1.0)

class RiskManager:
    def __init__(self, equity: float, portfolio: dict, risk_config: dict, throttle_config: dict):
        self.equity = equity; self.portfolio = portfolio; self.risk_config = risk_config
        self.throttle = DrawdownThrottle(equity, throttle_config)
    def calculate_position_size(self, atr: float, price: float) -> float:
        rf = self.throttle.get_risk_factor()
        if rf == 0.0 or atr <= 0: return 0.0
        risk_per = self.risk_config.get('risk_per_trade', 0.005) * rf
        stop_mult = self.risk_config.get('sl_atr_multiplier', 2.0)
        risk_amt = self.equity * risk_per
        stop_usd = atr * stop_mult
        return 0.0 if stop_usd <= 0 else risk_amt/stop_usd
    def check_pre_trade_vetoes(self, *args, **kwargs) -> bool:
        return True
