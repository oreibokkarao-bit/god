
import asyncio, logging
from typing import Dict, Any
from risk.risk_manager import RiskManager

class RiskManagerRunner:
    def __init__(self, config: Dict[str, Any], signal_queue: asyncio.Queue, order_queue: asyncio.Queue):
        self.log = logging.getLogger(self.__class__.__name__)
        self.cfg = config
        self.q_sig = signal_queue
        self.q_out = order_queue
        self.rm = RiskManager(
            equity=float(self.cfg.get("initial_equity_usd", 10000)),
            portfolio={},
            risk_config=self.cfg.get("risk_config", {}),
            throttle_config=self.cfg.get("throttle_config", {"warn_level":0.15,"halt_level":0.25})
        )
        self.pick_n = int(self.cfg.get("top_n", 15))

    async def run(self):
        self.log.info("RiskManagerRunner running.")
        while True:
            item = await self.q_sig.get()
            rows = item["scores"].to_dict(orient="records")
            approved = [{"symbol": r["symbol"], "sip_score": r["sip_score"]} for r in rows[:self.pick_n]]
            await self.q_out.put({"approved": approved})
