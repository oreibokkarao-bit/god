
# Unified Spot Screener (Fixed Imports)

Run with either:
```bash
python main.py
# or (recommended from parent dir)
python -m sip_engine_multi_fixed.main
```
